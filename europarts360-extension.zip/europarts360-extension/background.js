chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "searchEuroParts360",
    title: "Search EuroParts360 for '%s'",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "searchEuroParts360" && info.selectionText) {
    chrome.tabs.create({
      url: `https://europarts360.com/search?q=${encodeURIComponent(info.selectionText.trim())}`
    });
  }
});