document.addEventListener('DOMContentLoaded', () => {
  const qInput   = document.getElementById('q');
  const searchBtn = document.getElementById('searchBtn');
  const results  = document.getElementById('results');
  const brandWrap = document.getElementById('brandWrap');

  // ── Inline product search ───────────────────────────────────
  function search(term) {
    term = term.trim();
    if (!term) { results.innerHTML = ''; return; }

    results.innerHTML = '<div class="r-loading">Searching…</div>';

    const url = `https://europarts360.com/search/suggest.json?q=${encodeURIComponent(term)}&resources[type]=product&resources[limit]=4`;

    fetch(url)
      .then(r => { if (!r.ok) throw new Error(); return r.json(); })
      .then(data => {
        const products = data?.resources?.results?.products || [];
        results.innerHTML = '';

        if (!products.length) {
          results.innerHTML = `
            <div class="r-empty">
              No products found for "<strong>${term}</strong>".<br>
              <a href="https://europarts360.com/search?q=${encodeURIComponent(term)}" target="_blank">Search full catalogue ↗</a>
            </div>`;
          return;
        }

        products.forEach(p => {
          const inStock = p.available !== false;
          const raw = parseFloat(p.price || '0');
          const price = raw ? `$${raw.toFixed(2)}` : '';
          const img = p.image ? `<img class="r-img" src="${p.image}" alt="">` : `<div class="r-img-placeholder">🔩</div>`;

          const card = document.createElement('div');
          card.className = 'r-card';
          card.innerHTML = `
            ${img}
            <div class="r-info">
              <div class="r-title" title="${p.title}">${p.title}</div>
              ${price ? `<div class="r-price">${price}</div>` : ''}
              <div class="r-stock ${inStock ? 'in' : 'out'}">${inStock ? '✓ In Stock' : '✗ Out of Stock'}</div>
              <a class="r-view" href="https://europarts360.com${p.url}" target="_blank">View &amp; Order ↗</a>
            </div>`;
          results.appendChild(card);
        });

        // "See all results" footer link
        const more = document.createElement('div');
        more.className = 'r-more';
        more.innerHTML = `<a href="https://europarts360.com/search?q=${encodeURIComponent(term)}" target="_blank">See all results on site ↗</a>`;
        results.appendChild(more);
      })
      .catch(() => {
        results.innerHTML = `
          <div class="r-empty">
            Could not reach EuroParts360.<br>
            <a href="https://europarts360.com/search?q=${encodeURIComponent(term)}" target="_blank">Try on site ↗</a>
          </div>`;
      });
  }

  searchBtn.addEventListener('click', () => search(qInput.value));
  qInput.addEventListener('keypress', e => { if (e.key === 'Enter') search(qInput.value); });

  // ── Fault codes ────────────────────────────────────────────
  fetch('data.json')
    .then(r => r.json())
    .then(brands => {
      brands.forEach(brand => {
        const wrap = document.createElement('div');
        wrap.className = 'brand';

        const head = document.createElement('div');
        head.className = 'brand-head';
        head.innerHTML = `<span>${brand.brand}</span><span class="chev">▶</span>`;
        head.addEventListener('click', () => {
          wrap.classList.toggle('open');
          head.querySelector('.chev').textContent = wrap.classList.contains('open') ? '▼' : '▶';
        });

        const body = document.createElement('div');
        body.className = 'brand-body';

        brand.codes.forEach(item => {
          const card = document.createElement('div');
          card.className = 'code-card';
          card.innerHTML = `<strong>${item.code}</strong> — ${item.desc}`;
          card.addEventListener('click', () => {
            const dest = brand.article
              || `https://europarts360.com/search?q=${encodeURIComponent(item.code)}&type=article`;
            chrome.tabs.create({ url: dest });
          });
          body.appendChild(card);
        });

        wrap.appendChild(head);
        wrap.appendChild(body);
        brandWrap.appendChild(wrap);
      });
    })
    .catch(err => console.error('data.json error', err));
});